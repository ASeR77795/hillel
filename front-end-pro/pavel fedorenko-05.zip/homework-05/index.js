var num1 = prompt("первое число");
var num2 = prompt("второе число");
var num3 = prompt("третье число");
var text = "Среднее арефметическое чисел" + +num1 + num2 + num3 + "=";
alert(text + (+num1 + +num2 + +num3) / 3);
