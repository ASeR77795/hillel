var hour = prompt("Сколько часов нужно перевести в минуты и секунды");
var min = hour * 60;
var sec = hour * 60 * 60;
alert(min + "минут" + "\n" + sec + "секунд");
