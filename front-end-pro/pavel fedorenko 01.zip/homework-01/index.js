var one = "Name";
var two = "Surname";
var three = "tel";
var joined = one + two + three;
console.log(joined);

const x = 12345;
console.log(String(x).split("").join(" "));
